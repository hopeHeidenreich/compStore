var express = require('express');
var router = express.Router();

router.post('/save', (req, res) => {
    var form = req.body;
    var sqlCmd = 'INSERT INTO suppliers SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) throw error;
        res.end(JSON.stringify(result.insertId));
    })
});

router.get('/get', (req, res) => {
    var sqlCmd = 'SELECT * FROM suppliers';
    conn.query(sqlCmd, (error, result) => {
        if (error) throw error;
        else res.end(JSON.stringify(result));
    })
});

router.delete('/delete/:supid', (req, res) => {
    let supid = req.params.supid;
    let sqlCmd = 'DELETE FROM suppliers WHERE supid = ?';
    conn.query(sqlCmd, supid, (err, result) => {
      if (err) throw err;
      res.end();
    });
});

module.exports = router;
