var express = require('express');
var router = express.Router();

router.post('/save', (req, res) => {
    let form = req.body;
    let sqlCmd = 'INSERT INTO orders SET ?';
    conn.query(sqlCmd, form, (err, result) => {
        if (err) throw err;
        res.send(JSON.stringify(result.insertId));
        res.end();
    });
});

router.get('/get', (req, res) => {
    
    let queries = [
        'SELECT * FROM shippers',
        'SELECT * FROM customers',
        'SELECT * FROM employees',
        `SELECT orders.*, shippers.shipid, shippers.shipname, customers.custid, customers.custfname, employees.empid, employees.empfname
         FROM orders INNER JOIN shippers 
         ON orders.shipid = shippers.shipid
         INNER JOIN customers 
         ON orders.custid = customers.custid
         INNER JOIN employees 
         ON orders.empid = employees.empid`
    ];
    
    conn.query(queries.join(';'), (err, result) => {
        if (err) throw err;
         res.send({
            shippers: JSON.stringify(result[0]),
            customers: JSON.stringify(result[1]),
            employees: JSON.stringify(result[2]),
            orders: JSON.stringify(result[3])
         });
        res.end();
    })
});

router.delete('/delete/:ordersid', (req, res) => {
    let ordersid = req.params.ordersid;
    let sqlCmd = 'DELETE FROM orders WHERE ordersid = ?';
    conn.query(sqlCmd, ordersid, (err, result) => {
      if (err) throw err;
      res.end();
    });
});

module.exports = router;
