var express = require('express');
var router = express.Router();

router.post('/save', (req, res) => {
    var form = req.body;
    var sqlCmd = 'INSERT INTO employees SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) throw error;
        res.end(JSON.stringify(result.insertId));
    })
});

router.get('/get', (req, res) => {
    var sqlCmd = 'SELECT * FROM employees';
    conn.query(sqlCmd, (error, result) => {
        if (error) throw error;
        else res.end(JSON.stringify(result));
    })
});

router.delete('/delete/:empid', (req, res) => {
    let empid = req.params.empid;
    let sqlCmd = 'DELETE FROM employees WHERE empid = ?';
    conn.query(sqlCmd, empid, (err, result) => {
      if (err) throw err;
      res.end();
    });
});

module.exports = router;
