var express = require('express');
var router = express.Router();

router.post('/save', (req, res) => {
    let form = req.body;
    let sqlCmd = 'INSERT INTO products SET ?';
    conn.query(sqlCmd, form, (err, result) => {
        if (err) throw err;
        res.send(JSON.stringify(result.insertId));
        res.end();
    });
});

router.get('/get', (req, res) => {
    
    let queries = [
        'SELECT * FROM suppliers',
        'SELECT * FROM categories',
        `SELECT products.*, suppliers.supid, suppliers.supname, categories.catid, categories.catname
         FROM products INNER JOIN suppliers 
         ON products.supid = suppliers.supid
         INNER JOIN categories
         ON products.catid = categories.catid`
    ];
    
    conn.query(queries.join(';'), (err, result) => {
        if (err) throw err;
         res.send({
            suppliers: JSON.stringify(result[0]),
            categories: JSON.stringify(result[1]),
            products: JSON.stringify(result[2])
         });
        res.end();
    })
});

router.delete('/delete/:prodid', (req, res) => {
    let prodid = req.params.prodid;
    let sqlCmd = 'DELETE FROM products WHERE prodid = ?';
    conn.query(sqlCmd, prodid, (err, result) => {
      if (err) throw err;
      res.end();
    });
});

module.exports = router;
