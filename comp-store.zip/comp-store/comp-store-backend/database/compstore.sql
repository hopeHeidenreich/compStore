CREATE DATABASE  IF NOT EXISTS `compstore` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `compstore`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: compstore
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `catid` int NOT NULL AUTO_INCREMENT,
  `catname` varchar(150) NOT NULL,
  `catdesc` varchar(150) NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `catid_UNIQUE` (`catid`),
  UNIQUE KEY `catname_UNIQUE` (`catname`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Clothing','Shirts'),(3,'Pants','Pants'),(4,'Canned Food','Food in cans');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `custid` int NOT NULL AUTO_INCREMENT,
  `custfname` varchar(100) NOT NULL,
  `custlname` varchar(100) NOT NULL,
  `custaddress` varchar(150) NOT NULL,
  `custcity` varchar(100) NOT NULL,
  `custzip` varchar(45) NOT NULL,
  `custcountry` varchar(100) NOT NULL,
  `custphone` varchar(45) NOT NULL,
  PRIMARY KEY (`custid`),
  UNIQUE KEY `custid_UNIQUE` (`custid`),
  UNIQUE KEY `custfname_UNIQUE` (`custfname`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Hope','Heidenreich','14637 Fern Lake ct','Naples','34114','United States','2392315115'),(2,'Jade','Smith','123 Button Rd.','Portland','24118','United States','3424562157'),(3,'Adam','Johnson','432 Alphabet St','Seasame','88771','United States','5436652234'),(4,'Micheal','Scott','543 Mayberry Ave.','Scranton','44553','United States','4436432554');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `empid` int NOT NULL AUTO_INCREMENT,
  `empfname` varchar(100) NOT NULL,
  `emplname` varchar(100) NOT NULL,
  `empdob` date NOT NULL,
  `empemail` varchar(100) NOT NULL,
  PRIMARY KEY (`empid`),
  UNIQUE KEY `empid_UNIQUE` (`empid`),
  UNIQUE KEY `empfname_UNIQUE` (`empfname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Jim','Halpert','1988-06-09','jimH@gmail.com');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `ordersid` int NOT NULL AUTO_INCREMENT,
  `ordersdate` date NOT NULL,
  `shipid` int NOT NULL,
  `custid` int NOT NULL,
  `empid` int NOT NULL,
  PRIMARY KEY (`ordersid`),
  UNIQUE KEY `ordersid_UNIQUE` (`ordersid`),
  KEY `shipname_idx` (`shipid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `prodid` int NOT NULL AUTO_INCREMENT,
  `prodname` varchar(100) NOT NULL,
  `produnit` varchar(45) NOT NULL,
  `prodprice` varchar(45) NOT NULL,
  `catid` int NOT NULL,
  `supid` int NOT NULL,
  PRIMARY KEY (`prodid`),
  UNIQUE KEY `prodid_UNIQUE` (`prodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shippers`
--

DROP TABLE IF EXISTS `shippers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shippers` (
  `shipid` int NOT NULL AUTO_INCREMENT,
  `shipname` varchar(100) NOT NULL,
  `shipphone` varchar(45) NOT NULL,
  PRIMARY KEY (`shipid`),
  UNIQUE KEY `shipid_UNIQUE` (`shipid`),
  UNIQUE KEY `shipname_UNIQUE` (`shipname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shippers`
--

LOCK TABLES `shippers` WRITE;
/*!40000 ALTER TABLE `shippers` DISABLE KEYS */;
INSERT INTO `shippers` VALUES (1,'Jake Ryan Moving Company','8743321243'),(2,'Derek Sheperd Moving Co.','6535442352');
/*!40000 ALTER TABLE `shippers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `supid` int NOT NULL AUTO_INCREMENT,
  `supname` varchar(100) NOT NULL,
  `supaddress` varchar(150) NOT NULL,
  `supcity` varchar(100) NOT NULL,
  `supzip` varchar(45) NOT NULL,
  `supcountry` varchar(100) NOT NULL,
  `supphone` varchar(45) NOT NULL,
  PRIMARY KEY (`supid`),
  UNIQUE KEY `supid_UNIQUE` (`supid`),
  UNIQUE KEY `supname_UNIQUE` (`supname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'John Doe Paper Company','123A Alphabet St','Seasame','45521','United States','5433346664'),(2,'New Cloth Clothing Shop','123B Alphabet St','Sesame','45522','United States','2415541234');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-09  8:15:32
