import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/Home.vue'

import CategoriesView from '../views/Categories.vue'
import CustomersView from '../views/Customers.vue'
import EmployeesView from '../views/Employees.vue'
import OrdersView from '../views/Orders.vue'
import ProductsView from '../views/Products.vue'
import ShippersView from '../views/Shippers.vue'
import SuppliersView from '../views/Suppliers.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/cust',
      name: 'customers',
      component: CustomersView
    },
    {
      path: '/cat',
      name: 'categories',
      component: CategoriesView
    },
    {
      path: '/emp',
      name: 'employees',
      component: EmployeesView
    },
    {
      path: '/orders',
      name: 'orders',
      component: OrdersView
    },
    {
      path: '/prod',
      name: 'products',
      component: ProductsView
    },
    {
      path: '/ship',
      name: 'shippers',
      component: ShippersView
    },
    {
      path: '/sup',
      name: 'suppliers',
      component: SuppliersView
    },
  ]
})

export default router
