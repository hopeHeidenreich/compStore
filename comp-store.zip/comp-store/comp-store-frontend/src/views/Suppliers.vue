<script>
  export default {
    data() {
        return {
          suppliers: [],
          form: {
             supname: '',
             supaddress: '',
             supcity: '',
             supzip: '',
             supcountry: '',
             supphone: ''
          },
          updateID: 0,
        }
    }, 
    methods: {
      getSup(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/suppliers/get",
          success: function (data, status) {
            if (status === 'success'){
              console.log(data);
              $this.suppliers = JSON.parse(data);
            }
          }
        })
      },
      subSup(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/suppliers/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.suppliers.push({
                supid: JSON.parse(data),
                supname: $this.form.supname,
                supaddress: $this.form.supaddress,
                supcity: $this.form.supcity,
                supcountry: $this.form.supcountry,
                supzip: $this.form.supzip
              });
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteSup(supid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/suppliers/delete/${supid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.suppliers.splice(i, 1);
            }
          }
        });
      },
    },  
    created() {
      this.getSup();
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Suppliers Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-5 offset-1">
                            <label for="sname" style="padding-bottom: 1%;">Name</label>
                            <input v-model="form.supname" type="text" id="sname" class="form-control">
                        </div>
                        <div class="col-5">
                          <label for="sphone" style="padding-bottom: 1%;">Phone</label>
                          <input v-model="form.supphone" type="text" id="sphone" class="form-control">
                        </div>
                        
                    </div>
                    <div class="row">
                      <div class="col-4 offset-1">
                        <label for="address" style="padding-bottom: 1%;">Address</label>
                        <input v-model="form.supaddress" type="text" id="address" class="form-control">
                      </div>
                      <div class="col-2">
                          <label for="city" style="padding-bottom: 1%;">City</label>
                          <input v-model="form.supcity" type="text" id="city" class="form-control">
                        </div>
                        <div class="col-2">
                          <label for="country" style="padding-bottom: 1%;">Country</label>
                          <input v-model="form.supcountry" type="text" id="country" class="form-control">
                        </div>
                        <div class="col-2">
                          <label for="zip" style="padding-bottom: 1%;">ZIP</label>
                          <input v-model="form.supzip" type="text" id="zip" class="form-control">
                        </div>
                    </div>
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subSup()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Country</th>
                                <th>ZIP</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(sup, i) in suppliers">
                                <td>{{sup.supid}}</td>
                                <td>{{sup.supname}}</td>
                                <td>{{sup.supphone}}</td>
                                <td>{{sup.supaddress}}</td>
                                <td>{{sup.supcity}}</td>
                                <td>{{sup.supcountry}}</td>
                                <td>{{sup.supzip}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteSup(sup.supid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>