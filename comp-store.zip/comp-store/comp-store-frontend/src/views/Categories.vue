<script>
  export default {
    data() {
        return {
          categories: [],
          form: {
             catname: '',
             catdesc: ''
          },
          updateID: 0,
        }
    }, 
    methods: {
      getCat(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/categories/get",
          success: function (data, status) {
            if (status === 'success'){
              console.log(data);
              $this.categories = JSON.parse(data);
            }
          }
        })
      },
      subCat(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/categories/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.categories.push({
                catid: JSON.parse(data),
                catname: $this.form.catname,
                catdesc: $this.form.catdesc
              });
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteCat(catid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/categories/delete/${catid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.categories.splice(i, 1);
            }
          }
        });
      },
    },  
    created() {
      this.getCat();
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Categories Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-5 offset-1">
                            <label for="name" style="padding-bottom: 1%;">Name</label>
                            <input v-model="form.catname" type="text" id="name" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-10 offset-1">
                          <label for="desc" style="padding-bottom: 1%;">Description</label>
                          <input v-model="form.catdesc" type="text" id="desc" class="form-control">
                        </div>
                    </div>
                    
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subCat()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category Name</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(cat, i) in categories" :key="cat.catid">
                                <td>{{cat.catid}}</td>
                                <td>{{cat.catname}}</td>
                                <td>{{cat.catdesc}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteCat(cat.catid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>