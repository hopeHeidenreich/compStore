<script>

</script>

<template>
<div class="container-fluid">
  <div class="row">
    <img src="src/imgs/home.png" style="width: 50%; margin-left:25%; padding-top: 7%; padding-bottom: 7%">
  </div>   
</div>
</template>
