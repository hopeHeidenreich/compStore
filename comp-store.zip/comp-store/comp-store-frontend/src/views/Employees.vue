<script>
  export default {
    data() {
        return {
          employees: [],
          form: {
             empfname: '',
             emplname: '',
             empdob: '',
             empemail: ''
          },
          updateID: 0,
        }
    }, 
    methods: {
      getEmp(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/employees/get",
          success: function (data, status) {
            if (status === 'success'){
              console.log(data);
              $this.employees = JSON.parse(data);
            }
          }
        })
      },
      subEmp(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/employees/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.employees.push({
                empid: JSON.parse(data),
                empfname: $this.form.empfname,
                emplname: $this.form.emplname,
                empdob: $this.form.empdob,
                empemail: $this.form.empemail
              });
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteEmp(empid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/employees/delete/${empid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.employees.splice(i, 1);
            }
          }
        });
      },
    },  
    created() {
      this.getEmp();
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Employees Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-5 offset-1">
                            <label for="fname" style="padding-bottom: 1%;">Name</label>
                            <input v-model="form.empfname" type="text" id="fname" class="form-control">
                        </div>
                        <div class="col-5">
                          <label for="lname" style="padding-bottom: 1%;">Last Name</label>
                          <input v-model="form.emplname" type="text" id="lname" class="form-control">
                        </div>
                        
                        
                    </div>
                    <div class="row">
                      <div class="col-5 offset-1">
                        <label for="dob" style="padding-bottom: 1%;">Date of Birth</label>
                        <input v-model="form.empdob" type="date" id="dob" class="form-control">
                      </div>
                      <div class="col-5">
                          <label for="email" style="padding-bottom: 1%;">Email</label>
                          <input v-model="form.empemail" type="text" id="email" class="form-control">
                        </div>
                    </div>
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subEmp()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Date of Birth</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(emp, i) in employees" :key="emp.empid">
                                <td>{{emp.empid}}</td>
                                <td>{{emp.empfname}}</td>
                                <td>{{emp.emplname}}</td>
                                <td>{{emp.empdob}}</td>
                                <td>{{emp.empemail}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteEmp(emp.empid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>