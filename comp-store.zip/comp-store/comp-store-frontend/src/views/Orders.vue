<script>
  export default {
    data() {
      return {
        shippers: [],
        customers: [],
        employees: [],
        orders:[],
        form: {
          ordersdate: '',
          shipid: '',
          custid: '',
          empid: ''
        },
        updateID: 0,
      }
    },
    methods: {
      getOrder(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/orders/get",
          success: function (data, status) {
            if (status === 'success'){
              $this.orders = JSON.parse(data.orders);
              $this.shippers = JSON.parse(data.shippers);
              $this.customers = JSON.parse(data.customers);
              $this.employees = JSON.parse(data.employees);
            }
          }
        })
      },
      subOrder(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/orders/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.getOrder()
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteOrder(ordersid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/orders/delete/${ordersid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.orders.splice(i, 1);
            }
          }
        });
      },
    },  
    mounted() {
      this.getOrder();
      $('#selectCust').select2();
      $('#selectCust').on('change', () => {
        this.form.custid = $('#selectCust').val();
      });
      $('#selectShip').select2();
      $('#selectShip').on('change', () => {
        this.form.shipid = $('#selectShip').val();
      });
      $('#selectEmp').select2();
      $('#selectEmp').on('change', () => {
        this.form.empid = $('#selectEmp').val();
      });
    }
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Orders Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-5 offset-1">
                          <label for="date" style="padding-bottom: 1%;">Order Date</label>
                          <input v-model="form.ordersdate" type="date" id="date" class="form-control">
                        </div>
                        <div class="col-5">
                          <label for="selectShip" style="padding-bottom: 1%;">Shipper</label>
                          <select id="selectShip" class="form-control" style="width: 100%;">
                            <option value="" disabled selected>Choose Shipper...</option>
                            <option v-for="ship in shippers" v-bind:value="ship.shipid">{{ship.shipname}}</option>
                          </select>
                        </div>
                        
                        
                    </div>
                    <div class="row">
                      <div class="col-5 offset-1">
                        <label for="selectCust" style="padding-bottom: 1%;">Customer</label>
                        <select id="selectCust" class="form-control" style="width: 100%;">
                            <option value="" disabled selected>Choose Customer...</option>
                            <option v-for="cust in customers" v-bind:value="cust.custid">{{cust.custfname}}</option>
                          </select>
                      </div>
                      <div class="col-5">
                          <label for="selectEmp" style="padding-bottom: 1%;">Employee</label>
                          <select id="selectEmp" class="form-control" style="width: 100%;">
                            <option value="" disabled selected>Choose Employee...</option>
                            <option v-for="emp in employees" v-bind:value="emp.empid">{{emp.empfname}}</option>
                          </select>
                        </div>
                    </div>
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subOrder()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>Date</th>
                                <th>Shipper</th>
                                <th>Customer</th>
                                <th>Employee</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(order, i) in orders">
                                <td>{{order.ordersid}}</td>
                                <td>{{order.ordersdate}}</td>
                                <td>{{order.shipname}}</td>
                                <td>{{order.custfname}}</td>
                                <td>{{order.empfname}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteOrder(order.ordersid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>