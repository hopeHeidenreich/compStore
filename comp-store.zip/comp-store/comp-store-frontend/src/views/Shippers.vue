<script>
  export default {
    data() {
        return {
          shippers: [],
          form: {
             shipname: '',
             shipphone: ''
          },
          updateID: 0,
        }
    }, 
    methods: {
      getShip(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/shippers/get",
          success: function (data, status) {
            if (status === 'success'){
              console.log(data);
              $this.shippers = JSON.parse(data);
            }
          }
        })
      },
      subShip(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/shippers/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.shippers.push({
                catid: JSON.parse(data),
                shipname: $this.form.shipname,
                shipphone: $this.form.shipphone
              });
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteShip(shipid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/shippers/delete/${shipid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.shippers.splice(i, 1);
            }
          }
        });
      },
    },  
    created() {
      this.getShip();
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Shippers Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-5 offset-1">
                            <label for="shname" style="padding-bottom: 1%;">Name</label>
                            <input v-model="form.shipname" type="text" id="shname" class="form-control">
                        </div>
                        <div class="col-5">
                          <label for="shphone" style="padding-bottom: 1%;">Phone</label>
                          <input v-model="form.shipphone" type="text" id="shphone" class="form-control">
                        </div>
                        
                        
                    </div>
                  
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subShip()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(ship, i) in shippers">
                                <td>{{ship.shipid}}</td>
                                <td>{{ship.shipname}}</td>
                                <td>{{ship.shipphone}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteShip(ship.shipid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>