<script>
  export default {
    data() {
        return {
          products: [],
          suppliers: [],
          categories: [],
          form: {
             prodname: '',
             produnit: '',
             prodprice: '',
             catid: '',
             supid: ''
          },
          updateID: 0,
        }
    }, 
    methods: {
      getProd(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/products/get",
          success: function (data, status) {
            if (status === 'success'){
              $this.products = JSON.parse(data.products);
              $this.suppliers = JSON.parse(data.suppliers);
              $this.categories = JSON.parse(data.categories);
            }
          }
        })
      },
      subProd(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/products/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.getProd()
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteProd(prodid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/products/delete/${prodid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.products.splice(i, 1);
            }
          }
        });
      },
    },  
    mounted() {
      this.getProd();
      $('#selectSup').select2();
      $('#selectSup').on('change', () => {
        this.form.supid = $('#selectSup').val();
      });
      $('#selectCat').select2();
      $('#selectCat').on('change', () => {
        this.form.catid = $('#selectCat').val();
      });
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Products Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-4 offset-1">
                            <label for="name" style="padding-bottom: 1%;">Product Name</label>
                            <input v-model="form.prodname" type="text" id="name" class="form-control">
                        </div>
                        <div class="col-3">
                          <label for="unit" style="padding-bottom: 1%;">Unit</label>
                          <input v-model="form.produnit" type="text" id="unit" class="form-control">
                        </div>
                        <div class="col-3">
                          <label for="price" style="padding-bottom: 1%;">Price</label>
                          <input v-model="form.prodprice" type="text" id="price" class="form-control">
                        </div>
                        
                        
                    </div>
                    <div class="row">
                      <div class="col-5 offset-1">
                        <label for="selectCat" style="padding-bottom: 1%;">Category</label>
                        <select id="selectCat" class="form-control" style="width: 100%;">
                          <option value="" disabled selected>Choose Category...</option>
                          <option v-for="cat in categories" v-bind:value="cat.catid">{{cat.catname}}</option>
                        </select>
                      </div>
                      <div class="col-5">
                          <label for="selectSup" style="padding-bottom: 1%;">Supplier</label>
                          <select id="selectSup" class="form-control" style="width: 100%;">
                            <option value="" disabled selected>Choose Supplier...</option>
                            <option v-for="sup in suppliers" v-bind:value="sup.supid">{{sup.supname}}</option>
                          </select>
                        </div>
                    </div>
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subProd()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product Name</th>
                                <th>Unit</th>
                                <th>Price</th>
                                <th>Category</th>
                                <th>Supplier</th>
                                <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(prod, i) in products">
                                <td>{{prod.prodid}}</td>
                                <td>{{prod.prodname}}</td>
                                <td>{{prod.produnit}}</td>
                                <td>{{prod.prodprice}}</td>
                                <td>{{prod.catname}}</td>
                                <td>{{prod.supname}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteProd(prod.prodid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>