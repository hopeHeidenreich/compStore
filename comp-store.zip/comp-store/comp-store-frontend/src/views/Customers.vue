<script>
  export default {
    data() {
        return {
          customers: [],
          form: {
             custfname: '',
             custlname: '',
             custphone: '',
             custaddress: '',
             custcity: '',
             custcountry: '',
             custzip: '' 
          },
          updateID: 0,
        }
    }, 
    methods: {
      getCust(){
        let $this = this;
        $.ajax({
          type: "GET",
          url: "http://localhost:3000/customers/get",
          success: function (data, status) {
            if (status === 'success'){
              console.log(data);
              $this.customers = JSON.parse(data);
            }
          }
        })
      },
      subCust(){
        let $this = this;
        $.ajax({
          type: "POST",
          url: "http://localhost:3000/customers/save",
          data: this.form,
          success: function (data, status) {
            if (status === 'success'){
              $this.customers.push({
                customersid: JSON.parse(data),
                customersfname: $this.form.customersfname,
                customerslname: $this.form.customerslname,
                customersphone: $this.form.customersphone,
                customersaddress: $this.form.customersaddress,
                customerscity: $this.form.customerscity,
                customerscountry: $this.form.customerscountry,
                customerszip: $this.form.customerszip,
              });
              for (let i in $this.form){
                $this.form[i] = '';
              }
            }
          }
        })
        location.reload()
      },
      deleteCust(custid, i){
        let $this = this;
        $.ajax({
          type: "DELETE",
          url: `http://localhost:3000/customers/delete/${custid}`,
          success: function (data, status) {
            if (status === 'success'){
              $this.customers.splice(i, 1);
            }
          }
        });
      },
    },  
    created() {
      this.getCust();
    }, 
  }
</script>

<template>
<div>
    <h2 style="text-align:center">Customers Info</h2>
    <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-3 offset-1">
                            <label for="fname" style="padding-bottom: 1%;">Name</label>
                            <input v-model="form.custfname" type="text" id="fname" class="form-control">
                        </div>
                        <div class="col-3">
                          <label for="lname" style="padding-bottom: 1%;">Last Name</label>
                          <input v-model="form.custlname" type="text" id="lname" class="form-control">
                        </div>
                        <div class="col-4">
                          <label for="phone" style="padding-bottom: 1%;">Phone</label>
                          <input v-model="form.custphone" type="text" id="phone" class="form-control">
                        </div>
                        
                    </div>
                    <div class="row">
                      <div class="col-4 offset-1">
                        <label for="address" style="padding-bottom: 1%;">Address</label>
                        <input v-model="form.custaddress" type="text" id="address" class="form-control">
                      </div>
                      <div class="col-2">
                          <label for="city" style="padding-bottom: 1%;">City</label>
                          <input v-model="form.custcity" type="text" id="city" class="form-control">
                        </div>
                        <div class="col-2">
                          <label for="country" style="padding-bottom: 1%;">Country</label>
                          <input v-model="form.custcountry" type="text" id="country" class="form-control">
                        </div>
                        <div class="col-2">
                          <label for="zip" style="padding-bottom: 1%;">ZIP</label>
                          <input v-model="form.custzip" type="text" id="zip" class="form-control">
                        </div>
                    </div>
                    <br>
                    <div class="row col-2 offset-1">
                    <button class="btn btn-primary" @click="subCust()">Submit</button>
                    </div>
                    
                    <div class="row col-10 offset-1" style="padding-top:5%">
                      <table class="table table-striped table-hover">
                          <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Country</th>
                                <th>ZIP</th>
                                <th>Actions</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(cust, i) in customers" :key="cust.custid">
                                <td>{{cust.custid}}</td>
                                <td>{{cust.custfname}}</td>
                                <td>{{cust.custlname}}</td>
                                <td>{{cust.custphone}}</td>
                                <td>{{cust.custaddress}}</td>
                                <td>{{cust.custcity}}</td>
                                <td>{{cust.custcountry}}</td>
                                <td>{{cust.custzip}}</td>
                                <td>
                                  <button class="btn btn-danger" @click="deleteCust(cust.custid, i)"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                </div>
                
              </div>
</div>
</template>